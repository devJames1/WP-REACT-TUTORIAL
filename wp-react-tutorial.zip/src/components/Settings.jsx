import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Settings = () => {
  return (
    <React.Fragment>
      <h2>Hello from React</h2>
    </React.Fragment>
  );
};

export default Settings;
